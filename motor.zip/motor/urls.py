from django.urls import include, path
from motor import views, serializers, models
from rest_framework import routers, viewsets
from django.conf.urls import url



app_name = 'motor'
urlpatterns=[
    path('', views.login, name='login'), #prima pagina di login che fa passare a camera_list
    url(r'^(?P<pk>\d{1,2})/$', views.Index.as_view()),#vista di ciascuna camera con video, passandogli l'id
    path('camera_list', views.cameraList, name='camera_list'),#vista della camera_list




    url(r'^stepR/(?P<pk>\d{2})/$', views.StepR.as_view()), #giradestra prendendo in input l'id del motor
    url(r'^stepL/(?P<pk>\d{2})/$', views.StepL.as_view()),  #girasinistra prendendo in input l'd del motor
    url(r'^stepU/(?P<pk>\d{2})/$', views.StepU.as_view()),  #giraalto prendendo in input l'id del motor
    url(r'^stepD/(?P<pk>\d{2})/$', views.StepD.as_view()),  #girabasso prendendo in input l'id del motor
    url(r'^setpos/(?P<pk>\d{1,2})/(?P<pos>\d{1,3})/$', views.SetPos.as_view()), #setta la posizione direttamente prendendo id motor e le nuove posizioni
    url(r'^setpres/(?P<pk>\d{1,2})/(?P<id_preset>\d{1,2})/$', views.SetPreset.as_view()), #setta i preset dei motori, prende in ingresso l'id della camera e id preset
    url(r'^savepres/(?P<pk>\d{1,2})/(?P<id_preset>\d{1,2})/$', views.SalvaPreset.as_view()),#salva i preset dei motori, prende in ingresso l'id della camera e id preset
    url(r'^delpres/(?P<pk>\d{1,2})/(?P<id_preset>\d{1,2})/$', views.deletePreset.as_view()),#cancella un preset, passandogli l'id della camera e l'id el preset da eliminare

    url(r'^delCamera/(?P<pk>\d{1,2})/$', views.deleteCamera.as_view()), #cancella la camera passandogli l'id della camera

    path('on/<int:pk>/', views.On.as_view()), #prende il pin del led da accendere
    path('off/<int:pk>/', views.Off.as_view()), #prende il pin del led da spegnere

]
