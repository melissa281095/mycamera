from django.apps import AppConfig


class MotorConfig(AppConfig):
    name = 'motor'
