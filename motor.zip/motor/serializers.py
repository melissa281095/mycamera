from django.contrib.auth.models import User
from rest_framework import serializers

from .models import Motor, Camera, Preset,Led

class MotorSerializer(serializers.ModelSerializer):
    class Meta:
        model= Motor
        fields =('pin', 'pos')

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        user = User
        fields = ('name')

class CameraSerializer(serializers.ModelSerializer):
    class Meta:
        model = Camera
        fields = ('id', 'nome', 'motors', 'presets', 'url')

class PresetSerializer(serializers.ModelSerializer):
    class Meta:
        model = Preset
        fields = ('id','pinx', 'posx', 'piny', 'posy')


class LedSerializer(serializers.ModelSerializer):
    class Meta:
        model = Led
        fields = ('state', 'color', 'pin')
