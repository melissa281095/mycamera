from django.contrib import admin
from .models import Motor, Camera, Preset, Led


# Register your models here.

class LedAdmin(admin.ModelAdmin):
    list_display = ('state', 'color', 'pin')

admin.site.register(Led, LedAdmin)

class MotorAdmin(admin.ModelAdmin):
    list_display = ('pin', 'pos')


admin.site.register(Motor, MotorAdmin)


# admin.site.register(Choice)

class CameraAdmin(admin.ModelAdmin):
    list_display = ('id', 'nome', 'get_motors', 'get_presets', 'url')


admin.site.register(Camera, CameraAdmin)


class PresetAdmin(admin.ModelAdmin):
    list_display = ('id', 'pinx', 'posx', 'piny', 'posy')


admin.site.register(Preset, PresetAdmin)

admin.site.site_url = "/motor/camera_list"


