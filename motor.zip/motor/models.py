from django.db import models
from django.contrib.contenttypes.models import ContentType

class Motor(models.Model):
    pin=models.IntegerField(primary_key=True)
    pos=models.FloatField(default=7)



class Preset(models.Model):
    id = models.IntegerField(primary_key=True)
    pinx = models.IntegerField()
    posx = models.FloatField(default=0)
    piny = models.IntegerField()
    posy = models.FloatField(default= 0)




class Camera(models.Model):
    id = models.IntegerField(primary_key = True)
    nome = models.CharField(default = "camera", max_length=20)
    motors = models.ManyToManyField(Motor, max_length=8) #lista di motori
    presets = models.ManyToManyField(Preset, max_length=8) #lista di preset di Camera
    url = models.URLField(default = "", max_length=50) #URL videocamera


    def get_motors(self):
        return "\n".join([str(p.pin) for p in self.motors.all()])

    def get_presets(self):
        return "\n".join([str(p.id) for p in self.presets.all()])

    def get_preset(self):
        #return "\n".join([str(p.id) for p in self.presets.filter(id)])
        return self.presets



class Led(models.Model):
    state = models.BooleanField(default=False)
    color = models.CharField(max_length=10, default='')
    pin = models.IntegerField(primary_key=True)