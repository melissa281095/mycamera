from django.shortcuts import render

from django.urls import path

from motor.serializers import UserSerializer, MotorSerializer, CameraSerializer, PresetSerializer
from . import views, serializers

from django.http import HttpResponse

# from RPi import GPIO
import time

from rest_framework import viewsets
from rest_framework.views import APIView
from django.http import Http404
from rest_framework.response import Response


from django.contrib.auth.forms import  AuthenticationForm
from django.shortcuts import render,redirect

from .models import Motor, Camera, Preset,Led

def login(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            # log in the
            return redirect('motor:camera_list')

    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})


class Index(APIView):
    def get(self, request, pk):
        camera = Camera.objects.get(pk=pk)
        numP = camera.presets.count()

        try:
            return render(request, 'camera.html',
                      {'camera': camera, 'numP': numP})  # da sistemare Camera.objects.get(pk=1)
        except Camera.DoesNotExist:
            raise Http404

def cameraList(request):
    cameraList = Camera.objects.all()
    return render (request, 'camera_list.html', {'cameraList': cameraList})


class SetPos (APIView):
    def get_object(self, pk):
        try:
            return Motor.objects.get(pk=pk)
        except Motor.DoesNotExist:
            raise Http404

    def get(self, request, pk, pos):
        motor = self.get_object(pk)
        id = motor.pin


        x = ((int(pos) / 18) + 2)

        print("\n x: " + str(x) + "\n\n")

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(id, GPIO.OUT)
        p = GPIO.PWM(id, 50)  # GPIO id for PWM with 50Hz
        # p.start(((motor.pos)/18)+2) # init della posizione iniziale a quella data da motor.pos resente nel DB
        p.start(x)  # init a x-1 per girare a dx

        time.sleep(0.7)
        p.stop()


        motor.pos = pos  # modifica il campo pos dell'oggetto
        motor.save()

        motor_serializer = MotorSerializer(motor, data=request.data)
        if motor_serializer.is_valid():
            return Response(motor_serializer.data)

        motor = self.get_object(pk)
        motor = serializers.MotorSerializer(motor)
        return Response(motor.data)



class StepR (APIView):
    def get_object(self, pk):
        try:
            return Motor.objects.get(pk=pk)
        except Motor.DoesNotExist:
            raise Http404

    def get(self, request, pk):
        motor = self.get_object(pk)
        id = motor.pin
        pos = motor.pos


        x = ((int(pos) / 18) + 2)
        if pos>=0:
            print("\n x: " + str(x) + "\n\n")

            GPIO.setmode(GPIO.BCM)
            GPIO.setup(id, GPIO.OUT)
            p = GPIO.PWM(id, 50)  # GPIO id for PWM with 50Hz
            p.start(x-1)  # init a x-1 per girare a dx

            time.sleep(0.1)
            p.stop()

            nuova_pos = (x-3)*18

            motor.pos = nuova_pos  # modifica il campo pos dell'oggetto
            motor.save()

            motor_serializer = MotorSerializer(motor, data=request.data)
            if motor_serializer.is_valid():
                return Response(motor_serializer.data)

            motor = self.get_object(pk)
            motor = serializers.MotorSerializer(motor)
            return Response(motor.data)
        else:
            print("Error...")


class StepL (APIView):
    def get_object(self, pk):
        try:
            return Motor.objects.get(pk=pk)
        except Motor.DoesNotExist:
            raise Http404

    def get(self, request, pk):
        motor = self.get_object(pk)
        id = motor.pin
        pos = motor.pos


        x = ((int(pos) / 18) + 2)

        print("\n x: " + str(x) + "\n\n")

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(id, GPIO.OUT)
        p = GPIO.PWM(id, 50)  # GPIO id for PWM with 50Hz
        p.start(x+1)  # init a x-1 per girare a dx

        time.sleep(0.1)
        p.stop()

        nuova_pos = (x-1)*18

        motor.pos = nuova_pos  # modifica il campo pos dell'oggetto
        motor.save()

        motor_serializer = MotorSerializer(motor, data=request.data)
        if motor_serializer.is_valid():
            return Response(motor_serializer.data)

        motor = self.get_object(pk)
        motor = serializers.MotorSerializer(motor)
        return Response(motor.data)


class StepU (APIView):
    def get_object(self, pk):
        try:
            return Motor.objects.get(pk=pk)
        except Motor.DoesNotExist:
            raise Http404

    def get(self, request, pk):
        motor = self.get_object(pk)
        id = motor.pin
        posy = motor.pos


        y = ((int(posy) / 18) + 2)

        print("\n x: " + str(y) + "\n\n")

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(id, GPIO.OUT)
        p = GPIO.PWM(id, 50)  # GPIO id for PWM with 50Hz
        p.start(y+1)  # init a x-1 per girare a dx

        time.sleep(0.1)
        p.stop()

        nuova_pos = (y-1)*18

        motor.pos = nuova_pos  # modifica il campo pos dell'oggetto
        motor.save()

        motor_serializer = MotorSerializer(motor, data=request.data)
        if motor_serializer.is_valid():
            return Response(motor_serializer.data)

        motor = self.get_object(pk)
        motor = serializers.MotorSerializer(motor)
        return Response(motor.data)


class StepD (APIView):
    def get_object(self, pk):
        try:
            return Motor.objects.get(pk=pk)
        except Motor.DoesNotExist:
            raise Http404

    def get(self, request, pk):
        motor = self.get_object(pk)
        id = motor.pin
        posy = motor.pos


        y = ((int(posy) / 18) + 2)

        print("\n x: " + str(y) + "\n\n")

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(id, GPIO.OUT)
        p = GPIO.PWM(id, 50)  # GPIO id for PWM with 50Hz

        p.start(y-1)  # init a x-1 per girare a dx

        time.sleep(0.1)
        p.stop()

        nuova_pos = (y-3)*18

        motor.pos = nuova_pos  # modifica il campo pos dell'oggetto
        motor.save()

        motor_serializer = MotorSerializer(motor, data=request.data)
        if motor_serializer.is_valid():
            return Response(motor_serializer.data)

        motor = self.get_object(pk)
        motor = serializers.MotorSerializer(motor)
        return Response(motor.data)


class CameraDetail(APIView): #ritorna i dati di Camera
    def get_object(self, pk):
        try:
            return Camera.objects.get(pk=pk)
        except Camera.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        camera = self.get_object(pk)
        camera = serializers.CameraSerializer(camera)
        return Response(camera.data)


class SetPreset (APIView):
    def get_object(self, pk):
        try:
            return Camera.objects.get(pk=pk)
        except Camera.DoesNotExist:
            raise Http404

    def get(self, request, pk, id_preset):
        camera = self.get_object(pk)
        preset = Preset.objects.get(pk=id_preset)

        idx=preset.pinx
        idy=preset.piny



        id = camera.id
        pres_list = camera.presets.all()
        print("-_-__-_ pres_id:  " + str(pres_list))

        idpres=camera.presets.filter(pk=id_preset)[0]   #cerco se quel preset esiste già
        print("-_-__-_ :  " + str(idpres))


        if camera.presets.filter(pk=id_preset)[0]:
            if camera.presets.filter(pk= id_preset)[0].pinx==idx & camera.presets.filter(pk= id_preset)[0].piny==idy:
                print(" TRUE " + camera.presets.filter(pk= id_preset)[0].pinx)

        print("----------- " + str(camera.motors.filter(pk=camera.presets.filter(pk=id_preset)[0].pinx)))

        print("---------------------------> " + str(id_preset))

        x = ((int(camera.presets.filter(pk=id_preset)[0].posx) / 18) + 2) #l'id rimane ugaule m modofico solo le posizioni
        y = ((int(camera.presets.filter(pk= id_preset)[0].posy) / 18) + 2)



        print("\n x: " + str(x) + "\n\n")

# ---------- aggiungere un controllo per vedere se il preset è presente fra quelli della camera, se si sposta i motori altrimenti errore------------


        GPIO.setmode(GPIO.BCM)
        GPIO.setup(preset.pinx, GPIO.OUT)
        px = GPIO.PWM(preset.pinx, 50)  # GPIO id for PWM with 50Hz
        px.start(x)

        time.sleep(0.7)
        px.stop()

        GPIO.setmode(GPIO.BCM)
        GPIO.setup(preset.piny, GPIO.OUT)
        py = GPIO.PWM(preset.piny, 50)  # GPIO id for PWM with 50Hz

        py.start(y)

        time.sleep(0.7)
        py.stop()

        motorx = Motor.objects.get(pk=preset.pinx)  # modifica il campo pos dell'oggetto
        motorx.pos = preset.posx
        motorx.save()
        #print(motor1)

        motory = Motor.objects.get(pk=preset.piny)  # modifica il campo pos dell'oggetto
        motory.pos = preset.posy
        motory.save()


        preset_serializer = PresetSerializer(preset, data=request.data)


        if preset_serializer.is_valid():
            return Response(preset_serializer.data)

        motorlist = serializers.PresetSerializer(preset)

        return Response(motorlist.data)


class SalvaPreset (APIView):

    def get_object(self, pk):
        try:
            return Camera.objects.get(pk=pk)
        except Camera.DoesNotExist:
            raise Http404

    def get(self, request, pk, id_preset):
        camera = self.get_object(pk)

        motorx = camera.motors.all()[0]  #la camera ha due motori
        motory = camera.motors.all()[1]


        if camera.presets.filter(pk = id_preset): #==id_preset:
            preset = Preset.objects.get(pk=id_preset)    #nel caso in cui l'id del preset c'è salvo le vuove posizioni
            preset.posy = motory.pos
            preset.posx = motorx.pos

            preset.save()
            return ()


        else:       #ltrimento creo un nuovo preset e lo salvo

            newPres = Preset(pk=id_preset)
            newPres.pinx = motorx.pin
            newPres.piny = motory.pin
            newPres.posx = motorx.pos
            newPres.posy = motory.pos

            newPres.save()

            print("creato newPreset!!")

            camera.get_preset().add(newPres)  #aggiunto alla lista presets

            return(newPres)



class deletePreset(APIView):
    def get_object(self, pk):
        try:
            return Camera.objects.get(pk=pk)
        except Camera.DoesNotExist:
            raise Http404

    def get(self, request, pk, id_preset):
        camera = self.get_object(pk)

        preset = camera.presets.all().filter(pk=id_preset)
        preset.delete()




class deleteCamera(APIView):
    def get_object(self, pk):
        try:
            return Camera.objects.get(pk=pk)
        except Camera.DoesNotExist:

            raise Http404

    def get(self, request, pk):
        camera = self.get_object(pk)
        camera.delete()


class On(APIView):
    def get_object(self, pk):
        try:
            return Led.objects.get(pk=pk)
        except Led.DoesNotExist:
            raise Http404

    def get(self, request, pk):
        led = self.get_object(pk)
        id = led.pin

        print('id: ' + str(id))
        use_gpio = True
        print(use_gpio)
        if use_gpio:
            print('gpio')
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(id, GPIO.OUT)
            GPIO.output(id, GPIO.HIGH)
        #return render(request, 'led_on.html')

class Off (APIView):
    def get_object(self, pk):
        try:
            return Led.objects.get(pk=pk)
        except Led.DoesNotExist:
            raise Http404

    def get(self, request, pk):
        led = self.get_object(pk)
        id = led.pin

        print('id: ' + str(id))
        use_gpio = True
        print(use_gpio)
        if use_gpio:
            print('gpio')
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(id, GPIO.OUT)
            GPIO.output(id, GPIO.LOW)
        #return render(request, 'led/led_off.html')


